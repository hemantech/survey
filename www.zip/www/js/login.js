$("#btn_login").bind("click", function(event){
	//alert('hi');
	login();
	});
   
  
function login()
{
	location.href='expense_list.html';
}
